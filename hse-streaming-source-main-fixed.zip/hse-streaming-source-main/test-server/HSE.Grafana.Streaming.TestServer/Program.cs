using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace HSE.Grafana.Streaming.TestServer
{
	public class Program
	{
		public static void Main(string[] args)
		{
			CreateHostBuilder(args).Build().Run();
		}

		// Additional configuration is required to successfully run gRPC on macOS.
		// For instructions on how to configure Kestrel and gRPC clients on macOS, visit https://go.microsoft.com/fwlink/?linkid=2099682
		public static IHostBuilder CreateHostBuilder(string[] args) =>
			Host.CreateDefaultBuilder(args)
				.ConfigureWebHostDefaults(webBuilder =>
				{
					webBuilder.UseStartup<Startup>();
					webBuilder.ConfigureKestrel(options =>
					{
						// Each dashboard/user opens its own long-lived WebSocket ("upgraded")
						// connection. Kestrel's defaults are already unlimited here, but we set
						// this explicitly so a future change to the defaults doesn't silently
						// cap the number of concurrent viewers.
						options.Limits.MaxConcurrentUpgradedConnections = null;
						options.Limits.MaxConcurrentConnections = null;
					});
				});
	}
}
